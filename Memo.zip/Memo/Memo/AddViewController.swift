//
//  AddViewController.swift
//  Memo
//
//  Created by 土屋光暉 on 2018/06/05.
//  Copyright © 2018年 mitsuki.com. All rights reserved.
//

import UIKit
import NCMB


class AddViewController: UIViewController {
    
    @IBOutlet var memoTextView: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()

        memoTextView.becomeFirstResponder()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func saveMemo(){
        
        
        let  object = NCMBObject(className: "Memo")
        object?.setObject(memoTextView.text, forKey: "memo")
        
        object?.saveInBackground({ (error) in
            if error != nil{
                print("error")
            }else{
                let alertController = UIAlertController(title: "保存完了", message: "保存が完了しました。メモ一覧に戻ります。", preferredStyle: .alert)
                let action = UIAlertAction(title: "OK", style: .default, handler: { (action) in
                    self.navigationController?.popViewController(animated: true)
                })
                alertController.addAction(action)
                self.present(alertController, animated: true, completion: nil)
                
                
            }
        })
        
        
    }
    
    
    
    
}
