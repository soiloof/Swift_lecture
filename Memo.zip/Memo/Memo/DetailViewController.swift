//
//  DetailViewController.swift
//  Memo
//
//  Created by 土屋光暉 on 2018/06/05.
//  Copyright © 2018年 mitsuki.com. All rights reserved.
//

import UIKit
import NCMB
import SVProgressHUD


class DetailViewController: UIViewController {
    
    var selectedMemo: NCMBObject!
    
    @IBOutlet var memoTextView: UITextView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

       memoTextView.text = selectedMemo.object(forKey: "memo") as! String
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func upDate(){
        selectedMemo.setObject(memoTextView.text, forKey: "memo")
        selectedMemo.saveInBackground { (error) in
            if error != nil{
                SVProgressHUD.showError(withStatus: "Error")
            }else{
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    @IBAction func delete(){
        selectedMemo.deleteInBackground { (error) in
            if error != nil{
                print("error")
            }else{
                self.navigationController?.popViewController(animated: true)
            }
        }
    }

    

}
